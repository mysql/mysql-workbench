/**
 * Simplified js functions for WebHelp
 * Oracle
 */

/**
 * Code for Show/Hide TOC Element Updates
 *
 */
function showHideTocUpdate() {
    var showHideButton = $("#showHideButton");
    var showHideButtonFooter = $("#showHideButtonFooter");
    var navheader = $("#navheader");
    var toc_content = $("#content .toc > *")

    showHideButton.css("display","inline");
    showHideButtonFooter.css("display","inline");

    if (myLayout.state.west.isClosed) {
        showHideButton.removeClass('pointLeft').addClass('pointRight');
        showHideButton.attr("title", "Show Sidebar");
        showHideButton.text("Show Sidebar");
        showHideButtonFooter.removeClass('pointLeft').addClass('pointRight');
        showHideButtonFooter.attr("title", "Show Sidebar");
        showHideButtonFooter.text("Show Sidebar");
        navheader.css("left","auto");
        toc_content.css("display","block");

    } else {
        showHideButton.removeClass('pointRight').addClass('pointLeft');
        showHideButton.attr("title", "Hide Sidebar");
        showHideButton.text("Hide Sidebar");
        showHideButtonFooter.removeClass('pointRight').addClass('pointLeft');
        showHideButtonFooter.attr("title", "Hide Sidebar");
        showHideButtonFooter.text("Hide Sidebar");
        navheader.css("left","125px");
        toc_content.css("display","none");
    }
}

/*
 * Fix the skip to main content link for webkit browsers
 * https://code.google.com/p/chromium/issues/detail?id=37721
 * Give the id focus and add a highlight effect, based on this solution:
 * http://terrillthompson.com/blog/161
 */
$(document).ready(function() {
    $("a[href='#content']").click(function() {
    $("#"+$(this).attr("href").slice(1)+"")
    .focus()
    .effect("highlight", {}, 2000);
  });
});
